package com.proebac25.pwa_sql_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PwaSqlJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PwaSqlJavaApplication.class, args);
	}

}
